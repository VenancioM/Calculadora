package sistemas2;

public class operaciones {
    public static int Suma(int a, int b){
        return a+b;
    }
    public static int Resta(int a, int b){
        return a-b;
    }
    public static int Multiplicacion(int a, int b){
        return a*b;
    }
    public static int Division(int a, int b){
        if(b!=0){
            return a/b;
        }else{
            return 0;
        }
    }
    public static int Exponencial(int a, int b){
        int r = (int)Math.pow(a, b);
        return r;
    }
}
