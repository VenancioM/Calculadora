import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import sistemas2.operaciones;

public class operacionesTest {
   
    @Test//suma
    public void test1(){
        int esperado = 6;
        int actual = operaciones.Suma(3, 3);
        assertEquals(esperado,actual);
    }
   @Test
   public void test2(){
       int esperado = 3;
       int actual = operaciones.Suma(1, 2);
       assertEquals(esperado,actual);
   }
   
   @Test//resta
   public void test3(){
       int esperado = 2;
       int actual = operaciones.Resta(5, 3);
       assertEquals(esperado,actual);
   }
   
   @Test
   public void test4(){
       int esperado = 0;
       int actual = operaciones.Resta(2, 2);
       assertEquals(esperado,actual);
   }
   
   @Test//multiplicacion
   public void test5(){
       int esperado = 10;
       int actual = operaciones.Multiplicacion(5, 2);
       assertEquals(esperado,actual);
   }
   @Test
   public void test6(){
       int esperado = 6;
       int actual = operaciones.Multiplicacion(3, 2);
       assertEquals(esperado,actual);
   }
   
   @Test//division
   public void test7(){
       int esperado = 5;
       int actual = operaciones.Division(10, 2);
       assertEquals(esperado,actual);
   }
   @Test
   public void test8(){
       int esperado = 0;
       int actual = operaciones.Division(5, 0);
       assertEquals(esperado,actual);
   }
   
   @Test//Exponencial
   public void test9(){
       int esperado = 8;
       int actual = operaciones.Exponencial(2, 3);
       assertEquals(esperado, actual);
   }
   @Test
   public void test10(){
       int esperado = 78125;
       int actual = operaciones.Exponencial(5, 7);
       assertEquals(esperado,actual);
   }
}
